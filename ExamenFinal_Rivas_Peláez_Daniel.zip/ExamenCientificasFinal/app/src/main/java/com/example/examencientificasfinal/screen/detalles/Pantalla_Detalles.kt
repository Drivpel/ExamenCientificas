package com.example.examencientificasfinal.screen.detalles

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.examencientificasfinal.data.Mujeres
import com.example.examencientificasfinal.screen.lista.Pantalla_ListaVM

@Composable
fun DetalleScreen(
    navController: NavController,
    id: String?,
    viewModel: Pantalla_ListaVM
) {
    val idCientifica = id!!.toInt()
    val CientificaDetalle by viewModel.getCientifica(idCientifica).collectAsState(initial = emptyList())
    LazyColumn {
        items(CientificaDetalle) { cientifica ->
            MujerDetalleItem(cientifica)
        }
    }
}

@Composable
fun MujerDetalleItem(cientifica: Mujeres) {
    Column(modifier = Modifier.padding(bottom = 8.dp)) {
        Text(text = "Nombre: ${cientifica.name}", textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.padding(8.dp))
        Text(text = "Nombre: ${cientifica.logros}", textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.padding(8.dp))
        Text(text = "Nombre: ${cientifica.biografia}", textAlign = TextAlign.Center)
    }
}