

                Examen Final Cientificas


  Pantalla Principal:

               Un boton para entrar a la lista de Cientificas.

  Pantalla Lista:

               Lista donde se mostraran los nombres de las cientificas y si pulsa un nombre iras 
                a la pantalla detalle

  Pantalla Detalles:

               En esta pantalla se mostraran el nombre, la biografia y sus logros


