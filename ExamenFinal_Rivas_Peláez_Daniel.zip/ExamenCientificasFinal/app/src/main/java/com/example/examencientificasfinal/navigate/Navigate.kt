package com.example.examencientificasfinal.navigate

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.examencientificasfinal.screen.detalles.DetalleScreen
import com.example.examencientificasfinal.screen.lista.ListaScreen
import com.example.examencientificasfinal.screen.lista.Pantalla_ListaVM
import com.example.examencientificasfinal.screen.principal.PrincipalScreen

@Composable
fun Navigation(
    navController: NavHostController = rememberNavController()
) {
    val viewModel: Pantalla_ListaVM = viewModel(factory = Pantalla_ListaVM.factory)
    NavHost(
        navController = navController,
        startDestination = "inicio"
    ) {
        composable("inicio") {
            PrincipalScreen(navController)
        }
        composable("lista") {
            ListaScreen(navController, viewModel)
        }
        composable("detalle") {
            val id = it.arguments?.getString("id")
            DetalleScreen(navController, id, viewModel)
        }
    }
}