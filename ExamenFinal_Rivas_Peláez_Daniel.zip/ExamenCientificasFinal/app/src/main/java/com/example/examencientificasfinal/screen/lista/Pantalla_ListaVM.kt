package com.example.examencientificasfinal.screen.lista

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.examencientificasfinal.data.AppDatabase
import com.example.examencientificasfinal.data.Mujeres
import com.example.examencientificasfinal.data.MujeresDao
import kotlinx.coroutines.flow.Flow

class Pantalla_ListaVM(private val mujeresDao: MujeresDao) : ViewModel() {
    fun getAllAtun(): Flow<List<Mujeres>> = mujeresDao.getAllCientificas()
    fun getAtunName(name: String): Flow<List<Mujeres>> =
        mujeresDao.getCientificasName(name)
    fun getCientifica(id: Int): Flow<List<Mujeres>> = mujeresDao.getCientifica(id)
    companion object {
        val factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val context = this[APPLICATION_KEY] as Context
                val database = AppDatabase.getDatabase(context)
                Pantalla_ListaVM(database.mujeresDao())
            }
        }
    }
}
